const express = require("express");
const mysql = require("mysql");
const cors = require("cors");

const app = express();

app.use(express.json());
app.use(cors());

const con = mysql.createConnection({
    user: "root",
    host: "localhost",
    password: "",
    database: "register"
})

app.post('/register', (req, res) => {
    const email = req.body.email;
   
    const password = req.body.password;

    con.query("INSERT INTO users (email, password) VALUES (?, ?)", [email, password], 
        (err, result) => {
            if(result){
                res.send(result);
                console.log("Sucess");
            }else{
                res.send({message: "ENTER CORRECT ASKED DETAILS!"})
            }
        }
    )
})
app.get("/getUserData",(req,res)=>{

    con.query("SELECT * FROM gps",(err,result)=>{
        if(err){
            res.status(422).json("no data available");
        }else{
            res.status(201).json(result);
        }
    })
});
app.post("/login", (req, res) => {
    const email = req.body.email;
    const password = req.body.password;
    con.query("SELECT * FROM users WHERE email = ? AND password = ?", [email, password], 
        (err, result) => {
            if(err){
                req.setEncoding({err: err});
            }else{
                if(result.length > 0){
                    res.send(result);
                    console.log("Sucess");
                }else{
                    res.send({message: "WRONG USERNAME OR PASSWORD!"})
                }
            }
        }
    )
})


app.listen(3001, () => {
    console.log("running backend server");
})
import React, { Component, useState } from "react";
import Axios from "axios";
export default function Login() {

  const [email, setEmail] = useState("");
  const [loginStatus, setLoginStatus] = useState("");
  const [password, setPassword] = useState("");
  
  const login = (e) => {
    e.preventDefault();
    Axios.post("http://localhost:3001/login", {
      email: email,
      password: password,
    }).then((response) => {
      if(response.data.message){
        setLoginStatus(response.data.message);
        
      }else{
        setLoginStatus(response.data[0].email);
        window.localStorage.setItem("token", response.data);
        window.localStorage.setItem("loggedIn", true);

         window.location.href = "./userDetails";
        
      }
    })
  }
          
  
  return (
    <div className="auth-wrapper">
       <p></p>
     <p></p>
     <p></p>
     <p></p>
     <p></p>
     <p></p>
     <p><h2><center>GPS SUMMARY 
      WEB APPLICATION</center></h2></p>
      <div className="auth-inner">
        <form onSubmit={login}>
          <h3>Sign In</h3>

          <div className="mb-3">
            <label>Email address</label>
            <input
              type="email"
              className="form-control"
              placeholder="Enter email"
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>

          <div className="mb-3">
            <label>Password</label>
            <input
              type="password"
              className="form-control"
              placeholder="Enter password"
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>

          <div className="mb-3">
            <div className="custom-control custom-checkbox">
              <input
                type="checkbox"
                className="custom-control-input"
                id="customCheck1"
              />
              <label className="custom-control-label" htmlFor="customCheck1">
                Remember me
              </label>
            </div>
          </div>

          <div className="d-grid">
            <button type="submit" className="btn btn-primary">
              Submit
            </button>
          </div>
          <p className="forgot-password text-right">
            <a href="/sign-up">Sign Up</a>
          </p>
          <h1 style={{color: 'red', fontSize: '15px', textAlign: 'center', marginTop: '20px'}}>{loginStatus}</h1>
        </form>
      </div>
    </div>
  );
}

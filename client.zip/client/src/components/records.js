
import React from 'react'
const Records = ({userData}) => {

    return(
        <table  class="table">

                     <thead>
                                <tr className="table-dark">
                                <th scope="col">Device-Id</th>
                                
                                <th scope="col">Device-Type</th>
                                <th scope="col">TimeStamp</th>
                                <th scope="col">Location</th>
                               
                                <th scope="col"></th>
                            </tr>
                            
                         { userData.map( (userData, index)=>(                           
                        <tr key={index}>
                        <td>{ userData.did } </td>
                        <td>{ userData.dtype } </td>
                        <td>{ userData.timestamp } </td>
                        <td>{ userData.location } </td>
                        
                    
                        </tr>
                        )) 
                        }    
                        </thead>
                        </table>



    )}
    
    
export default Records;  
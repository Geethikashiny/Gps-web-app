import React, { Component, useEffect, useState } from "react";


import UserHome from "./userHome";


export default function UserDetails()
{
  const [userData, setUserData] = useState("");
  return  <UserHome userData={userData} />;
}
